/**
 * Created by anthony on 6/6/17.
 */
var config = {
    map: {
        '*': {
            hello: 'Learning_FifthUnit/js/hello',
        }
    }
};
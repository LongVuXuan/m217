/**
 * Created by anthony on 6/6/17.
 */
define([
        "jquery"
    ], function($){
        "use strict";
        return function(config, element) {
            console.log(config.message);
        }
    }
)
